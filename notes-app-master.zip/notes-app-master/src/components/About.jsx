import React, { useContext } from 'react';
// import noteContext from '../context/notes/noteContext';
// import { useEffect } from 'react';
export default function About() {
   
    return (
        <div>
            About this is about 
        </div>
    )
}
